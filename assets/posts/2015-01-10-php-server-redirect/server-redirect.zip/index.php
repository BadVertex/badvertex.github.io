<?php

$key = "eVZKwTTFYASm6orAgzjm";

if(isset($_GET['action'])) {
	if($_GET['action'] === "set") {
		if(isset($_GET['auth']) && $_GET['auth'] === $key) {
			file_put_contents("ip.txt", GetClientIp());
			die("OK");
		}
		else {
			die("Invalid request");
		}
	}
	else if($_GET['action'] === "get") {
		die(file_get_contents("ip.txt"));
	}
	else {
		die("Invalid request");
	}
}
else {
	$filepath = dirname(__FILE__);
	$pathExploded = explode(DIRECTORY_SEPARATOR, $filepath);
	$request = str_replace("/" . end($pathExploded), "", $_SERVER['REQUEST_URI']);

	header('Location: http://' . file_get_contents("ip.txt") . $request);
}


function GetClientIp() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

?>