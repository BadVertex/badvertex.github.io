﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace TestGame
{
    class RotatingBB
    {
        //protected Rectangle originalRect {get; set;}
        protected float rotation = 0.0f;

        protected float halfWidth;
        protected float halfHeight;
        protected float halfHyp;

        protected Vector2 origin { get; set; }
        protected Rectangle rect { get; private set; }


        public RotatingBB(Rectangle rect, float angle) {
            halfWidth = rect.Width / 2.0f;
            halfHeight = rect.Height / 2.0f;
            halfHyp = (float) Math.Sqrt( (rect.Width * rect.Width + rect.Height * rect.Height) / 2.0f );

            origin = new Vector2(rect.X + (rect.Width / 2.0f), rect.Y + (rect.Height / 2.0f));

            this.rect = rect;
            this.rotation = angle;
        }


        public void rotate(float angle)
        {
            rotation = (rotation + angle) % (float) (Math.PI * 2.0f);


        }


        private void recalibrate()
        {

        }

    }
}
