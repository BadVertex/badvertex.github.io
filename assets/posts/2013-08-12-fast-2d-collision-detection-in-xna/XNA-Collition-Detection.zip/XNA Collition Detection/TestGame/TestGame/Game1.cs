using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace TestGame
{

    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        int moveSpeed = 2;

        Texture2D playerTex;
        Rectangle playerRect;
        Line[] playerLines;

        Texture2D windowTex;
        Rectangle windowRect;
        Line[] windowLines;

        Vector2 playerOrigin;
        float playerRot = 0.0f;

        // DEBUG STUFF
        Texture2D white;
        Rectangle intersectRect;
        bool intersects = false;


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }


        protected override void Initialize()
        {

            

            base.Initialize();
        }

     
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);

            playerTex = Content.Load<Texture2D>("alien_hair");
            //playerTex = Content.Load<Texture2D>("red");
            playerRect = new Rectangle(100, 50, 200, 100);
            playerOrigin = new Vector2(playerTex.Width / 2, playerTex.Height / 2);

            //windowTex = Content.Load<Texture2D>("cracked_window");
            windowTex = Content.Load<Texture2D>("red");
            windowRect = new Rectangle(300, 300, 100, 100);

            white = new Texture2D(GraphicsDevice, 1, 1, false, SurfaceFormat.Color);
            white.SetData<Color>(new[] { Color.White });


            playerLines = generateBoundLines(playerTex, playerRect, 4);
            

            //playerLines = generateGrid(playerTex, playerRect, 10);
            windowLines = generateGrid(windowTex, windowRect, 5);

            //windowLines = generateBoundLines(windowTex, windowRect, 6);
        }

        protected override void UnloadContent()
        {
           
        }

        protected override void Update(GameTime gameTime)
        {
            Rectangle oldState = playerRect;

            Rectangle temp = getBoundsWithRotation(playerRect, playerRot);

            KeyboardState keyState = Keyboard.GetState();
            if (keyState.IsKeyDown(Keys.Left) && temp.X > 0) 
            {
                playerRect.X -= moveSpeed;
            }
            else if (keyState.IsKeyDown(Keys.Right) && temp.X < GraphicsDevice.Viewport.Width - temp.Width)
            {
                playerRect.X += moveSpeed;
            }

            if (keyState.IsKeyDown(Keys.Up) && temp.Y > 0)
            {
                playerRect.Y -= moveSpeed;
            }
            else if (keyState.IsKeyDown(Keys.Down) && temp.Y < GraphicsDevice.Viewport.Height - temp.Height)
            {
                playerRect.Y += moveSpeed;
            }


            if (keyState.IsKeyDown(Keys.A))
            {
                playerRot -= 0.01f;
               
            }
            else if (keyState.IsKeyDown(Keys.D))
            {
                playerRot += 0.01f;
                
            }


            // COLLISION CHECKS
            if (collides(temp, playerTex, windowRect, windowTex))
            {
                updateCollisionLines(playerLines, playerRect.X, playerRect.Y, playerRot, playerRect.Width / 2.0f, playerRect.Height / 2.0f);
                updateCollisionLines(windowLines, windowRect.X, windowRect.Y, 0.0f, windowRect.Width / 2.0f, windowRect.Height / 2.0f);

                if (lineCollide(playerLines, playerRect.X, playerRect.Y, windowLines, windowRect.X, windowRect.Y))
                {
                    Console.WriteLine("COLLIDES!!!" + DateTime.Now);

                    /********** UNCOMMENT FOR ENABLING COLLISION  **********************/
                    /*** NOTE: Does not take in calculation the rotation while colliding, needs to be pushed away ***/
                    //playerRect = oldState;
                }
                
            }
            

            base.Update(gameTime);
        }


        protected void updateCollisionLines(Line[] lines, float globalOffsetX, float globalOffsetY, float rotation, float localOriginX, float localOriginY)
        {
            foreach (Line l in lines)
            {
                l.setGlobalOffset(globalOffsetX, globalOffsetY);
                l.setRotation(localOriginX, localOriginY, rotation);
                l.recalculateRotation();
            }
        }


        protected bool lineCollide(Line[] l1, int offsetX1, int offsetY1, Line[] l2, int offsetX2, int offsetY2)
        {
            foreach(Line a in l1) {
                foreach (Line b in l2)
                {
                    if (Line.intersects(a, b))
                    {
                        return true;
                    }
                }
            }
            return false;
        }
      
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();
            
            // Move bounds opposite to origin offset
            Rectangle antiRotRect = playerRect;
            antiRotRect.X += playerRect.Width / 2;
            antiRotRect.Y += playerRect.Height / 2;

            spriteBatch.Draw(playerTex, antiRotRect, null, Color.White, playerRot, playerOrigin, SpriteEffects.None, 0f);
            //drawBorders(getBoundsWithRotation(playerRect, playerRot));

            spriteBatch.Draw(windowTex, windowRect, Color.White);


            // FOR DEBUG PURPOSES !!!!!!!!!!!
            if (intersects)
            {
                foreach (Line l in playerLines)
                {
                    l.draw(spriteBatch, white);
                }

                foreach (Line l in windowLines)
                {
                    l.draw(spriteBatch, white);
                }

                drawBorders(intersectRect);
            }

            spriteBatch.End();

            base.Draw(gameTime);
        }


        protected bool collides(Rectangle r1, Texture2D t1, Rectangle r2, Texture2D t2)
        {
            if (r1.Intersects(r2))
            {

                intersectRect = Rectangle.Intersect(r1, r2);
                intersects = true;

                return true;

            }
            else
            {
                intersects = false;
            }
            return false;
        }


        protected void drawBorders(Rectangle rect)
        {
            Rectangle tempRect = new Rectangle(rect.X, rect.Y, rect.Width, 1);
            spriteBatch.Draw(white, tempRect, Color.White);

            tempRect.Y = rect.Y + rect.Height;
            spriteBatch.Draw(white, tempRect, Color.White);

            tempRect.Height = rect.Height;
            tempRect.Width = 1;
            tempRect.Y = rect.Y;
            spriteBatch.Draw(white, tempRect, Color.White);

            tempRect.X = rect.X + rect.Width;
            spriteBatch.Draw(white, tempRect, Color.White);

        }

        protected Rectangle getBoundsWithRotation(Rectangle rect, float angle)
        {
            Vector2 origin = new Vector2((float)rect.X + rect.Width / 2.0f, (float)rect.Y + rect.Height / 2.0f);
            float rot = angle % (float)Math.PI / 2.0f;  // Rotate between 0 and 2pi
            //double halfRot = Math.Cos(Math.PI / 2.0);

            float dx = (float)Math.Abs(Math.Cos(angle)) * (rect.Width / 2.0f) + (float)Math.Abs(Math.Sin(angle)) * (rect.Height / 2.0f);
            float dy = (float)Math.Abs(Math.Sin(angle)) * (rect.Width / 2.0f) + (float)Math.Abs(Math.Cos(angle)) * (rect.Height / 2.0f);

            int x = (int)Math.Round(origin.X - dx);
            int y = (int)Math.Round(origin.Y - dy);
            int w = (int)Math.Round(dx * 2.0f);
            int h = (int)Math.Round(dy * 2.0f);

            return new Rectangle(x, y, w, h);
        }


        

        protected Line[] generateBoundLines(Texture2D tex, Rectangle destRect, int segments)
        {
            int texStepX = tex.Width / (segments + 1);
            int destStepX = destRect.Width / (segments + 1);

            int texStepY = tex.Height / (segments + 1);
            int destStepY = destRect.Height / (segments + 1);

            int halfHeight = tex.Height / 2;
            int halfWidth = tex.Width / 2;

            int pointCount = 4 * 2 * segments;
            int[] points = new int[pointCount];

            Color[] texData = new Color[tex.Width * tex.Height];
            tex.GetData<Color>(texData);

            int index = 0;
            // Top
            for (int step = 1; step <= segments; step++)
            {
                int xval = step * texStepX;
                int yval = halfHeight;
                
                for (int i = 0; i < halfHeight; i++)
                {
                    if (texData[xval + i * tex.Width] != Color.Transparent)
                    {
                        yval = i;
                        break;
                    }
                }

                points[index++] = xval;
                points[index++] = yval;
            }


            // Right
            index = (2 * segments);
            for (int step = 1; step <= segments; step++)
            {
                int xval = halfWidth;
                int yval = step * texStepY;

                for (int i = tex.Width - 1; i > halfWidth; i--)
                {
                    if (texData[i + yval * tex.Width] != Color.Transparent)
                    {
                        xval = i;
                        break;
                    }
                }

                points[index++] = xval;
                points[index++] = yval;
            }


            // Bottom
            index = 4 * segments;
            //for (int step = 1; step <= segments; step++)
            for (int step = segments; step > 0; step--)
            {
                int xval = step * texStepX;
                int yval = halfHeight;

                for (int i = tex.Height-1; i > halfHeight; i--)
                {
                    if (texData[xval + i * tex.Width] != Color.Transparent)
                    {
                        yval = i;
                        break;
                    }
                }

                points[index++] = xval;
                points[index++] = yval;
            }


            // Left
            index = (8 * segments) - 1;
            for (int step = 1; step <= segments; step++)
            {
                int xval = halfWidth;
                int yval = step * texStepY;

                for (int i = 0; i < tex.Width - 1; i++)
                {
                    if (texData[i + yval * tex.Width] != Color.Transparent)
                    {
                        xval = i;
                        break;
                    }
                }

                
                points[index--] = yval;
                points[index--] = xval;
            }


            float xScalar = (float)destRect.Width / tex.Width;
            float yScalar = (float)destRect.Height / tex.Height;

            //Console.WriteLine("SCALES: " + xScalar + " " + yScalar);

            for (int i = 0; i < pointCount; i+=2)
            {
                points[i] = (int)((float)points[i] * xScalar);
                points[i + 1] = (int)((float)points[i+1] * yScalar);
            }
            
            int lineCount = 4 * segments;
            Line[] l = new Line[lineCount];
           

            l[0] = new Line(points[pointCount - 2], points[pointCount - 1], points[0], points[1]);
            for (int pi = 2, li = 1; pi < pointCount; pi+=2, li++)
            {
                //Console.WriteLine(i + ": " + points[i]);
                l[li] = new Line(points[pi - 2], points[pi - 1], points[pi], points[pi + 1]);
            }

            return l;
        }







        protected Line[] generateGrid(Texture2D tex, Rectangle destRect, int segments)
        {
            int texStepX = tex.Width / (segments + 1);
            int destStepX = destRect.Width / (segments + 1);

            int texStepY = tex.Height / (segments + 1);
            int destStepY = destRect.Height / (segments + 1);

            // 2 per point, 2 points per line, 2 directions
            int pointCount = 2 * 2 * 2 * segments;
            int[] points = new int[pointCount];

            Color[] texData = new Color[tex.Width * tex.Height];
            tex.GetData<Color>(texData);

            int index = 0;


            // Generate Vertical Lines
            for (int i = 1; i <= segments; i++)
            {
                int xVal = i * texStepX;
                int yValStart = -1;
                int yValEnd = -1;

                //Console.WriteLine("Segment: " + i);

                for (int j = 0; j < tex.Height; j++)
                {
                    Color currentPixel = texData[xVal + j * tex.Width];

                    if (currentPixel != Color.Transparent)
                    {
                        yValStart = j;
                        //Console.WriteLine("From: (" + xVal + ", " + yValStart + ")");
                        break;
                    }
                }

                for (int j = tex.Height - 1; j > yValStart; j--)
                {
                    Color currentPixel = texData[xVal + j * tex.Width];

                    if (currentPixel != Color.Transparent)
                    {
                        yValEnd = j;
                        //Console.WriteLine("To: (" + xVal + ", " + yValEnd + ")");
                        break;
                    }
                }

                // Double check
                yValStart = (yValStart == -1) ? 0 : yValStart;
                yValEnd = (yValEnd == -1) ? tex.Height - 1 : yValEnd;

                points[index++] = xVal;
                points[index++] = yValStart;
                points[index++] = xVal;
                points[index++] = yValEnd;
            }


            // Generate Horizontal Lines
            for (int i = 1; i <= segments; i++)
            {
                int yVal = i * texStepY;
                int xValStart = -1;
                int xValEnd = -1;

                //Console.WriteLine("Segment: " + i);


                for (int j = 0; j < tex.Width; j++)
                {
                    Color currentPixel = texData[j + yVal * tex.Width];

                    if (currentPixel != Color.Transparent)
                    {
                        xValStart = j;
                        Console.WriteLine("From: (" + xValStart + ", " + yVal + ")");
                        break;
                    }
                }

                for (int j = tex.Width - 1; j > xValStart; j--)
                {
                    Color currentPixel = texData[j + yVal * tex.Width];

                    if (currentPixel != Color.Transparent)
                    {
                        xValEnd = j;
                        Console.WriteLine("To: (" + xValEnd + ", " + yVal + ")");
                        break;
                    }
                }

                // Double check
                xValStart = (xValStart == -1) ? 0 : xValStart;
                xValEnd = (xValEnd == -1) ? tex.Width - 1 : xValEnd;

                points[index++] = xValStart;
                points[index++] = yVal;
                points[index++] = xValEnd;
                points[index++] = yVal;
            }


            float xScalar = (float)destRect.Width / tex.Width;
            float yScalar = (float)destRect.Height / tex.Height;

            //Console.WriteLine("SCALES: " + xScalar + " " + yScalar);

            for (int i = 0; i < pointCount; i += 2)
            {
                points[i] = (int)((float)points[i] * xScalar);
                points[i + 1] = (int)((float)points[i + 1] * yScalar);
            }

            int lineCount = 2 * segments;
            Line[] l = new Line[lineCount];

            // Create Lines
            for (int pi = 0, li = 0; pi < pointCount; pi += 4, li++)
            {
                l[li] = new Line(points[pi], points[pi + 1], points[pi + 2], points[pi + 3]);
            }

            return l;
        }
    }
}
